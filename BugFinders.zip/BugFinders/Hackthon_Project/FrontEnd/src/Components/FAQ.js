export default function FAQ()
{
    return (
        <div>
            <h1>FAQs</h1>
        </div>
    )
}